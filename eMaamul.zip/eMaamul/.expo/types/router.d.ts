/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(tabs)` | `/(tabs)/` | `/(tabs)/debts` | `/(tabs)/inventory` | `/(tabs)/reports` | `/(tabs)/scanner` | `/(tabs)/settings` | `/..\components\InventoryContext` | `/_sitemap` | `/debts` | `/inventory` | `/login` | `/pin-verification` | `/reports` | `/scanner` | `/settings`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
