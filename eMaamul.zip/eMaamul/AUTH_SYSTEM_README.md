# eMaamul Authentication System

## Overview

The eMaamul app features a modern, secure authentication system built with React Native and SQLite. The system provides a smooth user experience with comprehensive form validation, error handling, and security features.

## Features

### 🔐 **Security Features**
- **Password Hashing**: Passwords are hashed before storage (simulated with base64 encoding)
- **Input Validation**: Comprehensive validation for all user inputs
- **SQL Injection Protection**: Parameterized queries prevent SQL injection attacks
- **Unique Constraints**: Username and email uniqueness enforced at database level
- **Session Management**: Proper logout functionality with state clearing

### 🎨 **User Experience**
- **Modern UI**: Clean, dark theme with green accent colors matching app branding
- **Real-time Validation**: Form validation with immediate feedback
- **Password Strength Indicator**: Visual password strength meter
- **Error Handling**: Specific error messages for different scenarios
- **Loading States**: Smooth loading indicators during authentication
- **Keyboard Awareness**: Proper keyboard handling and scrolling
- **Authentication Guard**: Automatic redirection based on login status

### 📱 **Form Features**
- **Password Visibility Toggle**: Show/hide password functionality
- **Auto-capitalization**: Proper text input settings
- **Email Validation**: Real-time email format validation
- **Username Requirements**: Minimum length and format validation
- **Password Requirements**: 
  - Minimum 8 characters
  - At least one uppercase letter
  - At least one lowercase letter
  - At least one number
  - At least one special character

### 🚪 **Logout Functionality**
- **Settings Screen**: Logout button with confirmation dialog
- **User Profile Display**: Shows logged-in user information
- **State Management**: Proper user state clearing on logout
- **Navigation**: Automatic redirect to login screen
- **Error Handling**: Robust error handling for logout failures

## File Structure

```
├── app/
│   ├── login.tsx          # Login screen with enhanced UX
│   ├── signup.tsx         # Signup screen with password strength
│   └── (tabs)/
│       └── settings.tsx   # Settings screen with logout functionality
├── components/
│   ├── AuthContext.tsx    # Authentication context and logic
│   └── AuthGuard.tsx      # Authentication guard component
├── utils/
│   ├── database.ts        # Database management utilities
│   └── testAuth.ts        # Authentication testing utilities
└── AUTH_SYSTEM_README.md  # This documentation
```

## Database Schema

```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

## Usage

### Login Screen (`/login`)
- Username and password fields
- Real-time validation
- Specific error messages for username/password issues
- Smooth navigation to signup

### Signup Screen (`/signup`)
- Username, email, password, and confirm password fields
- Password strength indicator
- Comprehensive validation
- Visual feedback for password requirements

### Settings Screen (`/settings`)
- User profile display showing logged-in user info
- Logout button with confirmation dialog
- Company settings and app preferences
- Currency selection

## API Methods

### AuthContext Methods

```typescript
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<{ success: boolean; message: string }>;
  signup: (username: string, email: string, password: string) => Promise<{ success: boolean; message: string }>;
  logout: () => Promise<{ success: boolean; message: string }>;
  checkAuth: () => Promise<void>;
  validatePassword: (password: string) => { isValid: boolean; errors: string[] };
}
```

### Database Manager Methods

```typescript
class DatabaseManager {
  initialize(): Promise<void>
  createUser(username: string, email: string, hashedPassword: string): Promise<User>
  findUserByUsername(username: string): Promise<User | null>
  findUserByEmail(email: string): Promise<User | null>
  getAllUsers(): Promise<User[]>
  deleteUser(userId: number): Promise<void>
  updateUser(userId: number, updates: Partial<User>): Promise<void>
}
```

## Authentication Flow

1. **App Launch**: AuthGuard checks user authentication status
2. **Not Logged In**: Redirects to login screen
3. **Login Success**: Redirects to main app (tabs)
4. **Logout**: Clears user state and redirects to login screen
5. **Session Management**: Automatic state management throughout the app

## Error Handling

The system provides specific error messages for different scenarios:

- **Username not found**: When login attempts with non-existent username
- **Invalid password**: When password doesn't match stored hash
- **Username already exists**: When signup attempts with existing username
- **Email already exists**: When signup attempts with existing email
- **Password requirements**: Specific feedback for password strength issues
- **Logout failures**: Proper error handling for logout operations

## Security Considerations

### Current Implementation
- Passwords are hashed using a simple base64 encoding (for demo purposes)
- Input sanitization and validation
- Parameterized SQL queries
- Unique constraints at database level
- Proper session state management

### Production Recommendations
- Use bcrypt or similar for password hashing
- Implement JWT tokens for session management
- Add rate limiting for login attempts
- Implement password reset functionality
- Add biometric authentication options
- Use HTTPS for all network communications
- Implement session timeout
- Add audit logging for authentication events

## Color Scheme

The authentication system uses the eMaamul brand colors:

- **Primary Background**: `#00002b` (Dark blue)
- **Secondary Background**: `#181a2a` (Darker blue for inputs)
- **Accent Color**: `#4CAF50` (Green for buttons and highlights)
- **Error Color**: `#ff6b6b` (Red for error states)
- **Logout Color**: `#F44336` (Red for logout button)
- **Text Colors**: `#ffffff` (White) and `#ffffff80` (Semi-transparent white)

## Future Enhancements

1. **Biometric Authentication**: Add fingerprint/face ID support
2. **Password Reset**: Email-based password recovery
3. **Remember Me**: Persistent login sessions
4. **Two-Factor Authentication**: SMS or app-based 2FA
5. **Social Login**: Google, Apple, or Facebook integration
6. **Account Verification**: Email verification for new accounts
7. **Session Management**: Proper token-based authentication
8. **Offline Support**: Local authentication when offline
9. **Session Timeout**: Automatic logout after inactivity
10. **Audit Logging**: Track authentication events

## Installation

The system requires `expo-sqlite` for database functionality:

```bash
npm install expo-sqlite
```

## Testing

To test the authentication system:

1. **Create Account**: Use the signup screen to create a new account
2. **Login**: Use the created credentials to login
3. **Logout**: Use the settings screen to logout
4. **Validation**: Test various validation scenarios:
   - Weak passwords
   - Invalid email formats
   - Duplicate usernames/emails
   - Empty fields
   - Logout functionality

## Troubleshooting

### Common Issues

1. **Database not initialized**: Ensure `expo-sqlite` is properly installed
2. **Unique constraint errors**: Check for existing usernames/emails
3. **Password validation**: Ensure password meets all requirements
4. **Navigation issues**: Verify router configuration
5. **Logout not working**: Check AuthContext implementation
6. **Authentication guard issues**: Verify user state management

### Debug Mode

Enable debug logging by checking the console for:
- Database initialization messages
- User creation/authentication logs
- Logout operation logs
- Error messages and stack traces

## Contributing

When contributing to the authentication system:

1. Follow the existing code style and patterns
2. Add proper error handling for new features
3. Update this documentation for any changes
4. Test thoroughly on both iOS and Android
5. Consider security implications of any changes
6. Test logout functionality thoroughly 