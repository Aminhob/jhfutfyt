# Firestore Security Rules Setup

## Current Issue
Your Firestore tests are showing "Missing or insufficient permissions" errors because the default Firestore security rules require authentication.

## Quick Fix for Testing (Temporary)

### Option 1: Allow Read/Write for Testing (⚠️ NOT for production)
In your Firebase Console:
1. Go to Firestore Database → Rules
2. Replace the rules with:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow read/write access for testing
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

### Option 2: Authenticated Users Only (Recommended)
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow authenticated users to access their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Allow authenticated users to access transactions and products
    match /transactions/{document} {
      allow read, write: if request.auth != null;
    }
    
    match /products/{document} {
      allow read, write: if request.auth != null;
    }
    
    // Allow test collections for testing
    match /test_writes/{document} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## Steps to Fix

### 1. Update Firestore Rules
1. Open [Firebase Console](https://console.firebase.google.com)
2. Select your project: `emaamuldata`
3. Go to Firestore Database → Rules
4. Update the rules (use Option 2 above)
5. Click "Publish"

### 2. Enable Authentication Methods
1. Go to Authentication → Sign-in method
2. Enable Email/Password authentication
3. Enable any other methods you want to use

### 3. Test Authentication
1. Use your login screen to create a test account
2. Sign in with the test account
3. Run the Firestore tests again

## Current Firestore Status
✅ Connection: Working  
❌ Write Operations: Permission denied  
❌ Read Operations: Permission denied  
❌ Authenticated Access: No user authenticated  

## Next Steps
1. Update Firestore security rules
2. Test user authentication through your login screen
3. Run Firestore tests with authenticated user
4. Verify all operations work correctly

## Production Security Rules Template
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can only access their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // User-specific collections
    match /users/{userId}/transactions/{transactionId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    match /users/{userId}/products/{productId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Deny all other access
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```
