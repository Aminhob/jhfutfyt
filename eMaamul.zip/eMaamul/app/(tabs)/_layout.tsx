import { Tabs } from 'expo-router';
import { Platform, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import React from 'react';

// This type is used to type the tab bar icon props
type TabBarIconProps = {
  focused: boolean;
  color: string;
  size: number;
};

// This type represents a tab screen configuration
type TabScreen = {
  name: string;
  title: string;
  iconName: keyof typeof Ionicons.glyphMap;
};

// Define your tab screens with their configurations
const tabScreens: TabScreen[] = [
  { name: 'index', title: 'Home', iconName: 'home' },
  { name: 'inventory', title: 'Inventory', iconName: 'cube' },
  { name: 'scanner', title: 'Scanner', iconName: 'qr-code' },
  { name: 'reports', title: 'Warbixin', iconName: 'stats-chart' },
  { name: 'debts', title: 'Deyn', iconName: 'wallet' },
  { name: 'settings', title: 'Dejinta', iconName: 'settings' },
];

export default function TabLayout() {
  const colorScheme = useColorScheme();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#007AFF',
        tabBarInactiveTintColor: '#8E8E93',
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colorScheme === 'dark' ? '#1C1C1E' : '#FFFFFF',
          borderTopColor: colorScheme === 'dark' ? '#2C2C2E' : '#E5E5EA',
          paddingBottom: Platform.OS === 'ios' ? 20 : 5,
          height: Platform.OS === 'ios' ? 85 : 60,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          marginBottom: Platform.OS === 'ios' ? 0 : 5,
        },
      }}>
      {tabScreens.map((screen) => (
        <Tabs.Screen
          key={screen.name}
          name={screen.name}
          options={{
            title: screen.title,
            tabBarIcon: ({ color, size }: TabBarIconProps) => (
              <Ionicons name={screen.iconName} size={size} color={color} />
            ),
          }}
        />
      ))}
    </Tabs>
  );
}
