import { useCurrency } from '@/components/CurrencyContext';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import React, { useState } from 'react';
import { Alert, FlatList, Modal, TextInput, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const TABS = [
  { key: 'receivables', label: 'Deyn laga amaahday' },
  { key: 'liabilities', label: 'Deynta lagugu leeyahay' },
];

type Debt = {
  id: string;
  customer: string;
  amount: number;
  date: string;
  status: 'paid' | 'unpaid';
  type: 'receivables' | 'liabilities';
};

const mockDebts: Debt[] = [
  { id: '1', customer: 'Axmed', amount: 100, date: '2024-06-01', status: 'unpaid', type: 'receivables' },
  { id: '2', customer: 'Layla', amount: 50, date: '2024-06-02', status: 'paid', type: 'liabilities' },
];

export default function DebtsScreen() {
  const { formatCurrency } = useCurrency();
  const [selectedTab, setSelectedTab] = useState<'receivables' | 'liabilities'>('receivables');
  const [debts, setDebts] = useState<Debt[]>(mockDebts);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingDebt, setEditingDebt] = useState<Debt | null>(null);
  const [form, setForm] = useState({ customer: '', amount: '', date: '', status: 'unpaid' });

  const openAddModal = () => {
    setEditingDebt(null);
    setForm({ customer: '', amount: '', date: '', status: 'unpaid' });
    setModalVisible(true);
  };

  const openEditModal = (debt: Debt) => {
    setEditingDebt(debt);
    setForm({
      customer: debt.customer,
      amount: String(debt.amount),
      date: debt.date,
      status: debt.status,
    });
    setModalVisible(true);
  };

  const handleSave = () => {
    if (!form.customer || !form.amount || !form.date) return;
    if (editingDebt) {
      setDebts(debts.map((d) =>
        d.id === editingDebt.id
          ? { ...editingDebt, ...form, amount: Number(form.amount), type: selectedTab, status: form.status as 'paid' | 'unpaid' }
          : d
      ));
    } else {
      setDebts([
        ...debts,
        { id: Date.now().toString(), ...form, amount: Number(form.amount), type: selectedTab, status: form.status as 'paid' | 'unpaid' },
      ]);
    }
    setModalVisible(false);
  };

  const handleDelete = (debt: Debt) => {
    Alert.alert('Tirtir Deyn', `Ma hubtaa inaad tirtirayso "${debt.customer}"?`, [
      { text: 'Ka noqo', style: 'cancel' },
      { text: 'Tirtir', style: 'destructive', onPress: () => setDebts(debts.filter((d) => d.id !== debt.id)) },
    ]);
  };

  const filteredDebts = debts.filter((d) => d.type === selectedTab);

  return (
    <SafeAreaView style={{ flex: 1 }} edges={["top", "left", "right"]}>
     
      <ThemedView style={{ flex: 1, backgroundColor: '#00002b', padding: 16 }}>
      <ThemedText style={{ color: 'white', fontSize: 24, fontWeight: 'bold', marginBottom: 1, marginTop: 10 }}>Deymaha </ThemedText>
        {/* Header with tabs */}
        <View style={{ padding: 16, paddingTop: 32, paddingBottom: 8 }}>
          <View style={{ flexDirection: 'row', marginBottom: 16 }}>
            {TABS.map((tab) => (
                          <TouchableOpacity
              key={tab.key}
              style={{ 
                flex: 1, 
                padding: 12, 
                backgroundColor: selectedTab === tab.key ? '#4CAF50' : '#181a2a', 
                borderRadius: 8, 
                marginHorizontal: 4, 
                borderWidth: 1, 
                borderColor: '#ffffff20' 
              }}
                onPress={() => setSelectedTab(tab.key as 'receivables' | 'liabilities')}
              >
                <ThemedText style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>{tab.label}</ThemedText>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        {/* FlatList with proper padding */}
        <FlatList
          data={filteredDebts}
          keyExtractor={item => item.id}
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 100 }}
          ListHeaderComponent={
            <ThemedText type="title" style={{ 
              marginBottom: 16, 
              color: 'white', 
              fontSize: 20, 
              fontWeight: 'bold',
              paddingHorizontal: 4
            }}>
              {selectedTab === 'receivables' ? 'Deymaha laga amaahday' : 'Deymaha adi lagugu leeyahay'}
            </ThemedText>
          }
          renderItem={({ item }) => (
            <View style={{ 
              backgroundColor: '#181a2a', 
              borderRadius: 12, 
              padding: 16, 
              marginBottom: 12, 
              flexDirection: 'row', 
              alignItems: 'center', 
              justifyContent: 'space-between', 
              borderWidth: 1, 
              borderColor: '#ffffff20',
              shadowColor: '#000',
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 2
            }}>
              <View style={{ flex: 1, marginRight: 12 }}>
                <ThemedText type="defaultSemiBold" style={{ color: 'white', fontSize: 16, marginBottom: 4 }}>{item.customer}</ThemedText>
                <ThemedText style={{ color: '#ffffff80', fontSize: 14 }}>
                  Qadarka: {formatCurrency(item.amount)} | Taariikh: {item.date} | Xaalad: {item.status === 'paid' ? 'La bixiyay' : 'La sugayo'}
                </ThemedText>
              </View>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <TouchableOpacity onPress={() => openEditModal(item)} style={{ 
                  backgroundColor: '#4CAF50', 
                  borderRadius: 8, 
                  paddingHorizontal: 12,
                  paddingVertical: 8 
                }}>
                  <ThemedText style={{ color: 'white', fontSize: 12, fontWeight: 'bold' }}>Edit</ThemedText>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => handleDelete(item)} style={{ 
                  backgroundColor: '#F44336', 
                  borderRadius: 8, 
                  paddingHorizontal: 12,
                  paddingVertical: 8 
                }}>
                  <ThemedText style={{ color: 'white', fontSize: 12, fontWeight: 'bold' }}>Delete</ThemedText>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />

        {/* Add/Edit Modal */}
        <Modal visible={modalVisible} animationType="slide" transparent>
          <SafeAreaView style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ 
              backgroundColor: '#181a2a', 
              borderRadius: 16, 
              padding: 24, 
              width: '90%', 
              maxWidth: 400,
              borderWidth: 1, 
              borderColor: '#ffffff20',
              shadowColor: '#000',
              shadowOpacity: 0.3,
              shadowRadius: 12,
              elevation: 8
            }}>
              <ThemedText style={{ color: 'white', fontSize: 22, fontWeight: 'bold', marginBottom: 24, textAlign: 'center' }}>
                {editingDebt ? 'Edit Debt' : 'Add New Debt'}
              </ThemedText>
              
              <TextInput
                placeholder="Customer Name"
                placeholderTextColor="#ffffff80"
                value={form.customer}
                onChangeText={(text) => setForm({ ...form, customer: text })}
                style={{ 
                  backgroundColor: '#00002b', 
                  color: 'white', 
                  borderWidth: 1, 
                  borderColor: '#ffffff20', 
                  borderRadius: 12, 
                  padding: 16, 
                  marginBottom: 16,
                  fontSize: 16
                }}
              />
              
              <TextInput
                placeholder="Amount"
                placeholderTextColor="#ffffff80"
                value={form.amount}
                onChangeText={(text) => setForm({ ...form, amount: text })}
                keyboardType="numeric"
                style={{ 
                  backgroundColor: '#00002b', 
                  color: 'white', 
                  borderWidth: 1, 
                  borderColor: '#ffffff20', 
                  borderRadius: 12, 
                  padding: 16, 
                  marginBottom: 16,
                  fontSize: 16
                }}
              />
              
              <TextInput
                placeholder="Date (YYYY-MM-DD)"
                placeholderTextColor="#ffffff80"
                value={form.date}
                onChangeText={(text) => setForm({ ...form, date: text })}
                style={{ 
                  backgroundColor: '#00002b', 
                  color: 'white', 
                  borderWidth: 1, 
                  borderColor: '#ffffff20', 
                  borderRadius: 12, 
                  padding: 16, 
                  marginBottom: 20,
                  fontSize: 16
                }}
              />
              
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 24 }}>
                <TouchableOpacity
                  onPress={() => setForm({ ...form, status: 'unpaid' })}
                  style={{ 
                    flex: 1, 
                    padding: 12, 
                    backgroundColor: form.status === 'unpaid' ? '#F44336' : '#00002b', 
                    borderRadius: 12, 
                    marginRight: 8, 
                    borderWidth: 1, 
                    borderColor: '#ffffff20' 
                  }}
                >
                  <ThemedText style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>Unpaid</ThemedText>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setForm({ ...form, status: 'paid' })}
                  style={{ 
                    flex: 1, 
                    padding: 12, 
                    backgroundColor: form.status === 'paid' ? '#4CAF50' : '#00002b', 
                    borderRadius: 12, 
                    marginLeft: 8, 
                    borderWidth: 1, 
                    borderColor: '#ffffff20' 
                  }}
                >
                  <ThemedText style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>Paid</ThemedText>
                </TouchableOpacity>
              </View>
              
              <View style={{ flexDirection: 'row', justifyContent: 'flex-end', gap: 12 }}>
                <TouchableOpacity 
                  onPress={() => setModalVisible(false)} 
                  style={{ 
                    backgroundColor: '#ffffff20', 
                    borderRadius: 12, 
                    paddingHorizontal: 24, 
                    paddingVertical: 12 
                  }}
                >
                  <ThemedText style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>Cancel</ThemedText>
                </TouchableOpacity>
                <TouchableOpacity 
                  onPress={handleSave} 
                  style={{ 
                    backgroundColor: '#ff3100', 
                    borderRadius: 12, 
                    paddingHorizontal: 24, 
                    paddingVertical: 12 
                  }}
                >
                  <ThemedText style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>Save</ThemedText>
                </TouchableOpacity>
              </View>
            </View>
          </SafeAreaView>
        </Modal>

        {/* Floating Action Button */}
        <TouchableOpacity
          style={{
            position: 'absolute',
            bottom: 32,
            right: 20,
            width: 60,
            height: 60,
            borderRadius: 30,
            backgroundColor: '#4CAF50',
            justifyContent: 'center',
            alignItems: 'center',
            shadowColor: '#4CAF50',
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 5
          }}
          onPress={openAddModal}
          accessibilityLabel="Ku dar Deyn"
        >
          <ThemedText style={{ color: 'white', fontSize: 24, fontWeight: 'bold' }}>+</ThemedText>
        </TouchableOpacity>
      </ThemedView>
    </SafeAreaView>
  );
} 