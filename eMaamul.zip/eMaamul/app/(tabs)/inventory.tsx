import { useCurrency } from '@/components/CurrencyContext';
import { useInventory } from '@/components/InventoryContext';
import { ProductInventoryCard } from '@/components/ProductInventoryCard';
import { QuickSellCard } from '@/components/QuickSellCard';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { useTransactions } from '@/components/TransactionsContext';
import Ionicons from '@expo/vector-icons/Ionicons';
import React, { useState } from 'react';
import { Alert, FlatList, Modal, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function InventoryScreen() {
  const { products, addProduct, updateProduct } = useInventory();
  const { addTransaction } = useTransactions();
  const { formatCurrency } = useCurrency();
  const [modalVisible, setModalVisible] = useState(false);
  const [sellModalVisible, setSellModalVisible] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);

  const availableProducts = products.filter(p => p.status !== 'sold');
  const soldProducts = products.filter(p => p.status === 'sold');

  const handleDeleteProduct = (id: string) => {
    Alert.alert(
      "Delete Product",
      "Are you sure you want to delete this product?",
      [
        { text: "Cancel", style: "cancel" },
        { text: "Delete", style: "destructive", onPress: () => {
          // Note: We don't have deleteProduct in context yet, so we'll just log for now
          console.log("Delete product:", id);
        }}
      ]
    );
  };

  const handleQuickSell = async (productId: string, soldPrice: number) => {
    try {
      // 1. Mark the product as sold
      await updateProduct(productId, { status: 'sold' });
      
      // 2. Create a transaction for the sale
      const date = new Date().toISOString().slice(0, 10);
      await addTransaction({
        type: 'income',
        label: selectedProduct.name,
        amount: soldPrice,
        date,
        icon: 'trending-up',
        productId: productId,
      });
      
      setSellModalVisible(false);
      setSelectedProduct(null);
    } catch (error) {
      console.error('Error in quick sell:', error);
      throw error;
    }
  };

  return (
    <SafeAreaView style={{ flex: 1 }} edges={["top", "left", "right"]}>
      <ThemedView style={{ flex: 1, backgroundColor: '#00002b', padding: 16 }}>
        <ThemedText style={{ color: 'white', fontSize: 24, fontWeight: 'bold', marginBottom: 24, marginTop: 16 }}>
          Kaydka alaabaha ama adeegyada
        </ThemedText>
        
        {availableProducts.length === 0 ? (
          <View style={{ 
            flex: 1, 
            justifyContent: 'center', 
            alignItems: 'center',
            paddingHorizontal: 32
          }}>
            <Ionicons name="cube-outline" size={64} color="#ffffff40" style={{ marginBottom: 16 }} />
            <ThemedText style={{ 
              color: '#ffffff80', 
              fontSize: 16, 
              textAlign: 'center',
              lineHeight: 24
            }}>
              Halkan waxaad ka arki doontaa alaabaha ama adeegyada aad kaydsatay, si aad wax ugu sii darto taabo + badhanka hoose
            </ThemedText>
          </View>
        ) : (
          <FlatList
            data={availableProducts}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={{ 
                backgroundColor: '#181a2a', 
                borderRadius: 12, 
                padding: 16, 
                marginBottom: 12,
                flexDirection: 'row',
                alignItems: 'center',
                shadowColor: '#000',
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 2
              }}>
                <View style={{ 
                  width: 50, 
                  height: 50, 
                  borderRadius: 25, 
                  backgroundColor: '#4CAF50',
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginRight: 12
                }}>
                  <Ionicons name="cube-outline" size={24} color="white" />
                </View>
                <View style={{ flex: 1 }}>
                  <ThemedText style={{ color: 'white', fontSize: 16, fontWeight: 'bold', marginBottom: 4 }}>
                    {item.name}
                  </ThemedText>
                  <ThemedText style={{ color: '#ffffff80', fontSize: 14 }}>
                    {formatCurrency(item.price)} • {item.category || 'No Category'}
                  </ThemedText>
                </View>
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <TouchableOpacity
                    onPress={() => {
                      setSelectedProduct(item);
                      setSellModalVisible(true);
                    }}
                    style={{ 
                      padding: 8,
                      backgroundColor: '#ff3100',
                      borderRadius: 8
                    }}
                  >
                    <Ionicons name="cash-outline" size={20} color="white" />
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => handleDeleteProduct(item.id)}
                    style={{ 
                      padding: 8,
                      backgroundColor: '#F44336',
                      borderRadius: 8
                    }}
                  >
                    <Ionicons name="trash-outline" size={20} color="white" />
                  </TouchableOpacity>
                </View>
              </View>
            )}
            showsVerticalScrollIndicator={false}
            ListFooterComponent={
              soldProducts.length > 0 ? (
                <View style={{ marginTop: 20 }}>
                  <ThemedText style={{ color: 'white', fontSize: 18, fontWeight: 'bold', marginBottom: 16 }}>
                    Alaabaha la iibiyay
                  </ThemedText>
                  {soldProducts.map((item) => (
                    <View key={item.id} style={{ 
                      backgroundColor: '#181a2a', 
                      borderRadius: 12, 
                      padding: 16, 
                      marginBottom: 12,
                      flexDirection: 'row',
                      alignItems: 'center',
                      shadowColor: '#000',
                      shadowOpacity: 0.1,
                      shadowRadius: 4,
                      elevation: 2,
                      opacity: 0.6
                    }}>
                      <View style={{ 
                        width: 50, 
                        height: 50, 
                        borderRadius: 25, 
                        backgroundColor: '#666666',
                        justifyContent: 'center',
                        alignItems: 'center',
                        marginRight: 12
                      }}>
                        <Ionicons name="checkmark-circle-outline" size={24} color="white" />
                      </View>
                      <View style={{ flex: 1 }}>
                        <ThemedText style={{ color: 'white', fontSize: 16, fontWeight: 'bold', marginBottom: 4 }}>
                          {item.name}
                        </ThemedText>
                        <ThemedText style={{ color: '#ffffff80', fontSize: 14 }}>
                          {formatCurrency(item.price)} • {item.category || 'No Category'} • La iibiyay
                        </ThemedText>
                      </View>
                    </View>
                  ))}
                </View>
              ) : null
            }
          />
        )}

        {/* Floating Action Button */}
        <TouchableOpacity
          style={{
            position: 'absolute',
            bottom: 20,
            right: 20,
            width: 60,
            height: 60,
            borderRadius: 30,
            backgroundColor: '#4CAF50',
            justifyContent: 'center',
            alignItems: 'center',
            shadowColor: '#4CAF50',
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 5
          }}
          onPress={() => setModalVisible(true)}
          accessibilityLabel="Ku dar Alaab"
        >
          <Ionicons name="add" size={32} color="white" />
        </TouchableOpacity>

        {/* Add Product Modal */}
        <Modal visible={modalVisible} animationType="slide" transparent>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
            <ProductInventoryCard
              existingProducts={products}
              onSubmit={({ name, price, category }) => {
                addProduct({ name, price: Number(price), category, status: 'available' });
                setModalVisible(false);
              }}
            />
            <TouchableOpacity
              style={{ marginTop: 12, alignSelf: 'center', backgroundColor: '#F44336', borderRadius: 20, paddingHorizontal: 24, paddingVertical: 10 }}
              onPress={() => setModalVisible(false)}
            >
              <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>Cancel</ThemedText>
            </TouchableOpacity>
          </View>
        </Modal>

        {/* Quick Sell Modal */}
        <Modal visible={sellModalVisible} animationType="slide" transparent>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
            {selectedProduct && (
              <QuickSellCard
                product={selectedProduct}
                onSell={handleQuickSell}
                onCancel={() => {
                  setSellModalVisible(false);
                  setSelectedProduct(null);
                }}
              />
            )}
          </View>
        </Modal>
      </ThemedView>
    </SafeAreaView>
  );
} 