import { useCurrency } from '@/components/CurrencyContext';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { useTransactions } from '@/components/TransactionsContext';
import React from 'react';
import { ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function ReportsScreen() {
  const { transactions } = useTransactions();
  const { formatCurrency } = useCurrency();

  // Calculate today's and this month's income/expense/net
  const today = new Date().toISOString().slice(0, 10);
  const thisMonth = new Date().toISOString().slice(0, 7);

  const todayIncome = transactions.filter(t => t.type === 'income' && t.date === today).reduce((sum, t) => sum + t.amount, 0);
  const todayExpense = transactions.filter(t => t.type === 'expense' && t.date === today).reduce((sum, t) => sum + t.amount, 0);
  const todayNet = todayIncome - todayExpense;

  const monthIncome = transactions.filter(t => t.type === 'income' && t.date.startsWith(thisMonth)).reduce((sum, t) => sum + t.amount, 0);
  const monthExpense = transactions.filter(t => t.type === 'expense' && t.date.startsWith(thisMonth)).reduce((sum, t) => sum + t.amount, 0);
  const monthNet = monthIncome - monthExpense;

  return (
    <SafeAreaView style={{ flex: 1 }} edges={["top", "left", "right"]}>
      <ThemedView style={{ flex: 1, backgroundColor: '#00002b', padding: 16 }}>
        <ScrollView contentContainerStyle={{ paddingBottom: 32 }} showsVerticalScrollIndicator={false}>
          <ThemedText style={{ color: 'white', fontSize: 22, fontWeight: 'bold', marginBottom: 24, marginTop: 8 }}>
            Warbixinnada libka & Kharashka
          </ThemedText>

          {/* Maanta Card */}
          <View style={{ backgroundColor: '#181a2a', borderRadius: 20, padding: 20, marginBottom: 24, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 8, elevation: 2 }}>
            <ThemedText style={{ color: '#ff3100', fontSize: 20, fontWeight: 'bold', marginBottom: 8 }}>Maanta</ThemedText>
            <View style={{ height: 1, backgroundColor: '#ffffff30', marginVertical: 8 }} />
            <ThemedText style={{ color: '#ffffffcc', fontSize: 16, marginBottom: 8 }}>iibka Maanta: <ThemedText style={{ color: '#4CAF50', fontWeight: 'bold' }}>{formatCurrency(todayIncome)}</ThemedText></ThemedText>
            <ThemedText style={{ color: '#ffffffcc', fontSize: 16, marginBottom: 8 }}>Kharashka Maanta: <ThemedText style={{ color: '#F44336', fontWeight: 'bold' }}>{formatCurrency(todayExpense)}</ThemedText></ThemedText>
            <ThemedText style={{ color: '#ffffffcc', fontSize: 16 }}>Net Maanta: <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>{formatCurrency(todayNet)}</ThemedText></ThemedText>
          </View>

          {/* Bishan Card */}
          <View style={{ backgroundColor: '#181a2a', borderRadius: 20, padding: 20, marginBottom: 24, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 8, elevation: 2 }}>
            <ThemedText style={{ color: '#ff3100', fontSize: 20, fontWeight: 'bold', marginBottom: 8 }}>Bishan</ThemedText>
            <View style={{ height: 1, backgroundColor: '#ffffff30', marginVertical: 8 }} />
            <ThemedText style={{ color: '#ffffffcc', fontSize: 16, marginBottom: 8 }}>iibka Bishan: <ThemedText style={{ color: '#4CAF50', fontWeight: 'bold' }}>{formatCurrency(monthIncome)}</ThemedText></ThemedText>
            <ThemedText style={{ color: '#ffffffcc', fontSize: 16, marginBottom: 8 }}>Kharashka Bishan: <ThemedText style={{ color: '#F44336', fontWeight: 'bold' }}>{formatCurrency(monthExpense)}</ThemedText></ThemedText>
            <ThemedText style={{ color: '#ffffffcc', fontSize: 16 }}>Net Bishan: <ThemedText style={{ color: 'white', fontWeight: 'bold' }}>{formatCurrency(monthNet)}</ThemedText></ThemedText>
          </View>
        </ScrollView>
      </ThemedView>
    </SafeAreaView>
  );
} 