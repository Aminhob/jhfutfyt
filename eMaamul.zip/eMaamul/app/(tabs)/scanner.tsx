import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { useInventory } from '@/components/InventoryContext';
import { useCurrency } from '@/components/CurrencyContext';
import Ionicons from '@expo/vector-icons/Ionicons';
import React, { useState, useEffect } from 'react';
import { View, TouchableOpacity, Alert, StyleSheet, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CameraView, Camera } from 'expo-camera';

const { width } = Dimensions.get('window');

export default function ScannerScreen() {
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [scanned, setScanned] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const { products, addProduct } = useInventory();
  const { currency } = useCurrency();

  useEffect(() => {
    const getCameraPermissions = async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
    };

    getCameraPermissions();
  }, []);

  const handleBarCodeScanned = ({ type, data }: { type: string; data: string }) => {
    setScanned(true);
    setIsScanning(false);
    
    // Check if product already exists
    const existingProduct = products.find(p => p.barcode === data);
    
    if (existingProduct) {
      Alert.alert(
        'Alaab La Helay',
        `Alaabta: ${existingProduct.name}\nQiimaha: ${currency.symbol}${existingProduct.price}`,
        [
          { text: 'OK', onPress: () => setScanned(false) }
        ]
      );
    } else {
      Alert.alert(
        'Alaab Cusub',
        `Barcode: ${data}\nMa rabtaa inaad ku darto alaabta cusub?`,
        [
          { text: 'Maya', style: 'cancel', onPress: () => setScanned(false) },
          { 
            text: 'Haa', 
            onPress: () => {
              // Add new product with scanned barcode
              const newProduct = {
                name: `Alaab ${data.slice(-6)}`,
                price: 0,
                quantity: 1,
                category: 'Kale',
                barcode: data
              };
              addProduct(newProduct);
              Alert.alert('Guul', 'Alaabta cusub waa lagu daray!', [
                { text: 'OK', onPress: () => setScanned(false) }
              ]);
            }
          }
        ]
      );
    }
  };

  const startScanning = () => {
    setIsScanning(true);
    setScanned(false);
  };

  const stopScanning = () => {
    setIsScanning(false);
    setScanned(false);
  };

  if (hasPermission === null) {
    return (
      <SafeAreaView style={styles.container}>
        <ThemedView style={styles.centerContent}>
          <Ionicons name="camera" size={64} color="#666" />
          <ThemedText style={styles.message}>Fadlan sug...</ThemedText>
        </ThemedView>
      </SafeAreaView>
    );
  }

  if (hasPermission === false) {
    return (
      <SafeAreaView style={styles.container}>
        <ThemedView style={styles.centerContent}>
          <Ionicons name="camera-off" size={64} color="#ff4444" />
          <ThemedText style={styles.message}>Ruqsad kaamerad ma laha</ThemedText>
          <ThemedText style={styles.subMessage}>
            Fadlan u ogolow app-ka inuu isticmaalo kaamerad-da si uu u akhriyo barcode-ka
          </ThemedText>
        </ThemedView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ThemedView style={styles.header}>
        <ThemedText type="title" style={styles.title}>
          Barcode Scanner
        </ThemedText>
        <ThemedText style={styles.subtitle}>
          Dhig barcode-ka hoosta kaamerad-da
        </ThemedText>
      </ThemedView>

      <View style={styles.cameraContainer}>
        {isScanning ? (
          <CameraView
            style={styles.camera}
            facing="back"
            onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
            barcodeScannerSettings={{
              barcodeTypes: ['qr', 'pdf417', 'ean13', 'ean8', 'code128', 'code39'],
            }}
          >
            <View style={styles.overlay}>
              <View style={styles.scanArea}>
                <View style={styles.corner} />
                <View style={[styles.corner, styles.topRight]} />
                <View style={[styles.corner, styles.bottomLeft]} />
                <View style={[styles.corner, styles.bottomRight]} />
              </View>
              <ThemedText style={styles.scanText}>
                Dhig barcode-ka gudaha sanduuqa
              </ThemedText>
            </View>
          </CameraView>
        ) : (
          <View style={styles.placeholderCamera}>
            <Ionicons name="qr-code" size={120} color="#666" />
            <ThemedText style={styles.placeholderText}>
              Riix batoonka hoose si aad u bilowdo scan-ka
            </ThemedText>
          </View>
        )}
      </View>

      <View style={styles.controls}>
        {!isScanning ? (
          <TouchableOpacity style={styles.scanButton} onPress={startScanning}>
            <Ionicons name="scan" size={24} color="white" />
            <ThemedText style={styles.buttonText}>Bilow Scan-ka</ThemedText>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.stopButton} onPress={stopScanning}>
            <Ionicons name="stop" size={24} color="white" />
            <ThemedText style={styles.buttonText}>Jooji Scan-ka</ThemedText>
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.info}>
        <View style={styles.infoItem}>
          <Ionicons name="information-circle" size={20} color="#666" />
          <ThemedText style={styles.infoText}>
            Scanner-ku wuxuu aqriyaa QR codes, EAN, Code128, iyo noocyo kale
          </ThemedText>
        </View>
        <View style={styles.infoItem}>
          <Ionicons name="cube" size={20} color="#666" />
          <ThemedText style={styles.infoText}>
            Alaabta la scan-gareeyo waxaa lagu dari doonaa inventory-ga
          </ThemedText>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    backgroundColor: '#00002b',
  },
  title: {
    color: 'white',
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    color: '#ffffff80',
    fontSize: 16,
  },
  cameraContainer: {
    flex: 1,
    margin: 20,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: '#000',
  },
  camera: {
    flex: 1,
  },
  placeholderCamera: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
  },
  placeholderText: {
    marginTop: 16,
    textAlign: 'center',
    color: '#666',
    fontSize: 16,
  },
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scanArea: {
    width: 250,
    height: 250,
    position: 'relative',
  },
  corner: {
    position: 'absolute',
    width: 30,
    height: 30,
    borderColor: '#00ff00',
    borderWidth: 3,
    top: 0,
    left: 0,
    borderRightWidth: 0,
    borderBottomWidth: 0,
  },
  topRight: {
    top: 0,
    right: 0,
    left: 'auto',
    borderLeftWidth: 0,
    borderRightWidth: 3,
    borderBottomWidth: 0,
  },
  bottomLeft: {
    bottom: 0,
    left: 0,
    top: 'auto',
    borderRightWidth: 0,
    borderTopWidth: 0,
    borderBottomWidth: 3,
  },
  bottomRight: {
    bottom: 0,
    right: 0,
    top: 'auto',
    left: 'auto',
    borderLeftWidth: 0,
    borderTopWidth: 0,
    borderRightWidth: 3,
    borderBottomWidth: 3,
  },
  scanText: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 20,
    backgroundColor: 'rgba(0,0,0,0.7)',
    padding: 10,
    borderRadius: 8,
  },
  controls: {
    padding: 20,
  },
  scanButton: {
    backgroundColor: '#4CAF50',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  stopButton: {
    backgroundColor: '#f44336',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  message: {
    fontSize: 18,
    textAlign: 'center',
    marginTop: 16,
  },
  subMessage: {
    fontSize: 14,
    textAlign: 'center',
    marginTop: 8,
    color: '#666',
  },
  info: {
    padding: 20,
    paddingTop: 0,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  infoText: {
    flex: 1,
    fontSize: 14,
    color: '#666',
  },
});
