import { useAuth } from '@/components/AuthContext';
import { useCurrency } from '@/components/CurrencyContext';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { auth } from '@/config/firebase';
import Ionicons from '@expo/vector-icons/Ionicons';
import { router } from 'expo-router';
import { EmailAuthProvider, reauthenticateWithCredential, updatePassword } from 'firebase/auth';
import React, { useState } from 'react';
import { ActivityIndicator, Alert, Modal, ScrollView, Share, TextInput, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function SettingsScreen() {
  const { logout, user, setPIN, checkPINExists } = useAuth();
  const { formatCurrency, currentCurrency, setCurrentCurrency, availableCurrencies } = useCurrency();
  const [currencyModalVisible, setCurrencyModalVisible] = useState(false);
  const [aboutModalVisible, setAboutModalVisible] = useState(false);
  const [changePasswordModalVisible, setChangePasswordModalVisible] = useState(false);
  const [pinModalVisible, setPinModalVisible] = useState(false);
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [isSettingPin, setIsSettingPin] = useState(false);
  const [isPinEnabled, setIsPinEnabled] = useState(false);

  // Check if PIN is enabled on component mount
  React.useEffect(() => {
    checkPinStatus();
  }, []);

  const checkPinStatus = async () => {
    try {
      const hasPIN = await checkPINExists();
      setIsPinEnabled(hasPIN);
    } catch (error) {
      console.error('Error checking PIN status:', error);
    }
  };

  const handleLogout = async () => {
    Alert.alert(
      "Logout",
      "Are you sure you want to logout?",
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Logout", 
          style: "destructive", 
          onPress: async () => {
            try {
              const result = await logout();
              if (result.success) {
                // Navigate to login screen
                router.replace('/login');
              } else {
                Alert.alert('Error', result.message);
              }
            } catch (error) {
              Alert.alert('Error', 'Logout failed. Please try again.');
            }
          }
        }
      ]
    );
  };

  const handleChangePassword = async () => {
    console.log('Change password attempt started');
    
    if (!currentPassword.trim() || !newPassword.trim() || !confirmPassword.trim()) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    if (newPassword !== confirmPassword) {
      Alert.alert('Error', 'New passwords do not match');
      return;
    }

    if (newPassword.length < 6) {
      Alert.alert('Error', 'New password must be at least 6 characters long');
      return;
    }

    setIsChangingPassword(true);
    try {
      if (!auth.currentUser) {
        Alert.alert('Error', 'No user logged in');
        return;
      }

      // Re-authenticate user with current password
      const credential = EmailAuthProvider.credential(
        auth.currentUser.email!,
        currentPassword
      );
      await reauthenticateWithCredential(auth.currentUser, credential);

      // Update password
      await updatePassword(auth.currentUser, newPassword);
      
      Alert.alert('Success', 'Password changed successfully', [
        {
          text: 'OK',
          onPress: () => {
            setChangePasswordModalVisible(false);
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
          }
        }
      ]);
    } catch (error: any) {
      console.error('Password change error:', error);
      Alert.alert('Error', error.message || 'Failed to change password');
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleSetPin = async () => {
    if (!pin.trim() || !confirmPin.trim()) {
      Alert.alert('Khalad', 'Fadlan buuxi dhammaan meelaha');
      return;
    }

    if (pin.length !== 4) {
      Alert.alert('Khalad', 'PIN-ka waa inuu ahaadaa 4 xaraf');
      return;
    }

    if (pin !== confirmPin) {
      Alert.alert('Khalad', 'PIN-ka lama midayn');
      return;
    }

    if (!/^\d{4}$/.test(pin)) {
      Alert.alert('Khalad', 'PIN-ka waa inuu ka kooban yahay tirooyin kaliya');
      return;
    }

    setIsSettingPin(true);
    try {
      // Use the new AuthContext setPIN function
      const result = await setPIN(pin);
      
      if (result.success) {
        Alert.alert('Guul', 'PIN-ka waa la dejiyay. Waxaad u baahan tahay inaad geliso PIN-kan marka aad dib u furaan app-ka.', [
          {
            text: 'Haa',
            onPress: () => {
              setPinModalVisible(false);
              setPin('');
              setConfirmPin('');
              checkPinStatus(); // Update PIN status
            }
          }
        ]);
      } else {
        Alert.alert('Khalad', result.message);
      }
    } catch (error) {
      console.error('PIN setting error:', error);
      Alert.alert('Khalad', 'PIN-ka lama dejin. Fadlan isku day mar kale.');
    } finally {
      setIsSettingPin(false);
    }
  };

  const handleRemovePin = async () => {
    Alert.alert(
      'Ka saar PIN-ka',
      'Ma hubtaa inaad ka saareyso PIN-ka app-ka? Tani waxay ka dhigan tahay in la ka saaro PIN-ka difaaca.',
      [
        { text: 'Maya', style: 'cancel' },
        { 
          text: 'Ka saar', 
          style: 'destructive', 
          onPress: async () => {
            try {
              // Remove PIN by setting it to empty string (this will clear it)
              const result = await setPIN('');
              if (result.success) {
                setIsPinEnabled(false);
                Alert.alert('Guul', 'PIN-ka waa la ka saaray');
              } else {
                Alert.alert('Khalad', result.message);
              }
            } catch (error) {
              console.error('Error removing PIN:', error);
              Alert.alert('Khalad', 'PIN-ka lama ka saarin. Fadlan isku day mar kale.');
            }
          }
        }
      ]
    );
  };

  const handleShareApp = async () => {
    try {
      await Share.share({
        message: 'eMaamul - App xisaabeed Casri ah oo loogu talagalay ganacsatada Soomaaliyeed. Download it now!',
        title: 'eMaamul - Somali Business Accounting App'
      });
    } catch (error) {
      console.log('Error sharing app:', error);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1 }} edges={["top", "left", "right"]}>
      <ThemedView style={{ flex: 1, backgroundColor: '#00002b', padding: 16 }}>
        <ThemedText style={{ color: 'white', fontSize: 24, fontWeight: 'bold', marginBottom: 24, marginTop: 16 }}>Settings</ThemedText>
        
        {/* Profile Section */}
        <View style={{ backgroundColor: '#181a2a', borderRadius: 16, padding: 20, marginBottom: 24, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 8, elevation: 2 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
            <View style={{ width: 60, height: 60, borderRadius: 30, backgroundColor: '#ff3100', justifyContent: 'center', alignItems: 'center', marginRight: 16 }}>
              <Ionicons name="business" size={32} color="white" />
            </View>
            <View style={{ flex: 1 }}>
              <ThemedText style={{ color: 'white', fontSize: 18, fontWeight: 'bold' }}> eMaamul</ThemedText>
              <ThemedText style={{ color: '#ffffff80', fontSize: 14 }}>Maamulaha casriga ah ee Ganasigaaga </ThemedText>
            </View>
          </View>
          
          {/* User Info */}
          {user && (
            <View style={{ borderTopWidth: 1, borderTopColor: '#ffffff20', paddingTop: 16 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                <Ionicons name="person" size={16} color="#ff3100" style={{ marginRight: 8 }} />
                <ThemedText style={{ color: 'white', fontSize: 14, fontWeight: 'bold' }}>Waxaad ku jirtaa cinwaanka:</ThemedText>
              </View>
              <ThemedText style={{ color: '#ffffff80', fontSize: 14, marginLeft: 24 }}>{user.email}</ThemedText>
            </View>
          )}
        </View>

        {/* Settings Options */}
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Currency Settings */}
          <View style={{ backgroundColor: '#181a2a', borderRadius: 16, padding: 20, marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 8, elevation: 2 }}>
            <ThemedText style={{ color: 'white', fontSize: 18, fontWeight: 'bold', marginBottom: 16 }}>Currency Settings</ThemedText>
            
            <TouchableOpacity 
              style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12 }}
              onPress={() => setCurrencyModalVisible(true)}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Ionicons name="cash-outline" size={20} color="#ff3100" style={{ marginRight: 12 }} />
                <ThemedText style={{ color: 'white', fontSize: 16 }}>Currency</ThemedText>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <ThemedText style={{ color: '#ffffff80', fontSize: 14, marginRight: 8 }}>{currentCurrency.symbol} {currentCurrency.name}</ThemedText>
                <Ionicons name="chevron-forward" size={16} color="#ffffff80" />
              </View>
            </TouchableOpacity>
          </View>

          {/* App Settings */}
          <View style={{ backgroundColor: '#181a2a', borderRadius: 16, padding: 20, marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 8, elevation: 2 }}>
            <ThemedText style={{ color: 'white', fontSize: 18, fontWeight: 'bold', marginBottom: 16 }}>App Settings</ThemedText>
            
                          <TouchableOpacity 
                style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#ffffff20' }}
                onPress={handleShareApp}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Ionicons name="share-outline" size={20} color="#ff3100" style={{ marginRight: 12 }} />
                  <ThemedText style={{ color: 'white', fontSize: 16 }}>Share App</ThemedText>
                </View>
                <Ionicons name="chevron-forward" size={16} color="#ffffff80" />
              </TouchableOpacity>

              <TouchableOpacity 
                style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#ffffff20' }}
                onPress={() => setChangePasswordModalVisible(true)}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Ionicons name="lock-closed-outline" size={20} color="#ff3100" style={{ marginRight: 12 }} />
                  <ThemedText style={{ color: 'white', fontSize: 16 }}>Change Password</ThemedText>
                </View>
                <Ionicons name="chevron-forward" size={16} color="#ffffff80" />
              </TouchableOpacity>

              <TouchableOpacity 
                style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#ffffff20' }}
                onPress={() => setPinModalVisible(true)}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Ionicons name="keypad-outline" size={20} color="#ff3100" style={{ marginRight: 12 }} />
                  <ThemedText style={{ color: 'white', fontSize: 16 }}>App PIN</ThemedText>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <ThemedText style={{ color: isPinEnabled ? '#4CAF50' : '#ffffff80', fontSize: 14, marginRight: 8 }}>
                    {isPinEnabled ? 'Enabled' : 'Disabled'}
                  </ThemedText>
                  <Ionicons name="chevron-forward" size={16} color="#ffffff80" />
                </View>
              </TouchableOpacity>

              {isPinEnabled && (
                <TouchableOpacity 
                  style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#ffffff20' }}
                  onPress={handleRemovePin}
                >
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Ionicons name="trash-outline" size={20} color="#F44336" style={{ marginRight: 12 }} />
                    <ThemedText style={{ color: '#F44336', fontSize: 16 }}>Remove PIN</ThemedText>
                  </View>
                  <Ionicons name="chevron-forward" size={16} color="#F44336" />
                </TouchableOpacity>
              )}

            <TouchableOpacity 
              style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#ffffff20' }}
              onPress={() => setAboutModalVisible(true)}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Ionicons name="information-circle-outline" size={20} color="#ff3100" style={{ marginRight: 12 }} />
                <ThemedText style={{ color: 'white', fontSize: 16 }}>About</ThemedText>
              </View>
              <Ionicons name="chevron-forward" size={16} color="#ffffff80" />
            </TouchableOpacity>

            <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Ionicons name="help-circle-outline" size={20} color="#ff3100" style={{ marginRight: 12 }} />
                <ThemedText style={{ color: 'white', fontSize: 16 }}>Help & Support</ThemedText>
              </View>
              <Ionicons name="chevron-forward" size={16} color="#ffffff80" />
            </TouchableOpacity>
          </View>

          {/* Logout Button */}
          <TouchableOpacity 
            style={{ backgroundColor: '#F44336', borderRadius: 16, padding: 16, alignItems: 'center', marginTop: 16 }}
            onPress={handleLogout}
          >
            <ThemedText style={{ color: 'white', fontSize: 16, fontWeight: 'bold' }}>Logout</ThemedText>
          </TouchableOpacity>
        </ScrollView>

        {/* Currency Selection Modal */}
        <Modal visible={currencyModalVisible} animationType="slide" transparent>
          <SafeAreaView style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ 
              backgroundColor: '#181a2a', 
              borderRadius: 16, 
              padding: 24, 
              width: '90%', 
              maxWidth: 400,
              maxHeight: '80%',
              borderWidth: 1,
              borderColor: '#ffffff20',
              shadowColor: '#000',
              shadowOpacity: 0.3,
              shadowRadius: 12,
              elevation: 8
            }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                <ThemedText style={{ color: 'white', fontSize: 20, fontWeight: 'bold' }}>Select Currency</ThemedText>
                <TouchableOpacity onPress={() => setCurrencyModalVisible(false)}>
                  <Ionicons name="close" size={24} color="#ffffff80" />
                </TouchableOpacity>
              </View>
              
              {/* This section was removed as per the new_code, as it was not in the new_code */}
              {/* <FlatList
                data={availableCurrencies}
                keyExtractor={(item) => item.code}
                renderItem={({ item }) => (
                                      <TouchableOpacity
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        paddingVertical: 16,
                        paddingHorizontal: 12,
                        borderRadius: 8,
                        backgroundColor: currentCurrency.code === item.code ? '#ff3100' : 'transparent',
                        marginBottom: 4,
                      }}
                    onPress={() => {
                      setCurrentCurrency(item);
                      setCurrencyModalVisible(false);
                    }}
                  >
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <ThemedText style={{ color: 'white', fontSize: 24, marginRight: 12 }}>{item.symbol}</ThemedText>
                      <View>
                        <ThemedText style={{ color: 'white', fontSize: 16, fontWeight: 'bold' }}>{item.name}</ThemedText>
                        <ThemedText style={{ color: '#ffffff80', fontSize: 12 }}>{item.code}</ThemedText>
                      </View>
                    </View>
                    {currentCurrency.code === item.code && (
                      <Ionicons name="checkmark" size={20} color="white" />
                    )}
                  </TouchableOpacity>
                )}
                showsVerticalScrollIndicator={false}
              /> */}
            </View>
          </SafeAreaView>
        </Modal>



        {/* About Modal */}
        <Modal visible={aboutModalVisible} animationType="slide" transparent>
          <SafeAreaView style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ 
              backgroundColor: '#181a2a', 
              borderRadius: 16, 
              padding: 24, 
              width: '90%', 
              maxWidth: 400,
              borderWidth: 1, 
              borderColor: '#ffffff20',
              shadowColor: '#000',
              shadowOpacity: 0.3,
              shadowRadius: 12,
              elevation: 8
            }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
                <ThemedText style={{ color: 'white', fontSize: 22, fontWeight: 'bold' }}>About eMaamul</ThemedText>
                <TouchableOpacity onPress={() => setAboutModalVisible(false)}>
                  <Ionicons name="close" size={24} color="#ffffff80" />
                </TouchableOpacity>
              </View>
              
              <View style={{ marginBottom: 24 }}>
                <ThemedText style={{ 
                  color: 'white', 
                  fontSize: 16, 
                  lineHeight: 24,
                  textAlign: 'left'
                }}>
                  eMaamul waa app xisaabeed Casri ah oo loogu talagalay ganacsatada Soomaaliyeed si ay u maareeyaan dakhliga, kharashaadka, iyo daymaha meheradahooda si fudud oo hufan.
                </ThemedText>
              </View>
              
              <View style={{ flexDirection: 'row', justifyContent: 'flex-end' }}>
                <TouchableOpacity 
                  onPress={() => setAboutModalVisible(false)} 
                  style={{ 
                    backgroundColor: '#ff3100', 
                    borderRadius: 12, 
                    paddingHorizontal: 24, 
                    paddingVertical: 12 
                  }}
                >
                  <ThemedText style={{ color: 'white', fontWeight: 'bold', fontSize: 16 }}>Close</ThemedText>
                </TouchableOpacity>
              </View>
            </View>
          </SafeAreaView>
        </Modal>

        {/* PIN Modal */}
        <Modal visible={pinModalVisible} animationType="slide" transparent>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ backgroundColor: '#181830', borderRadius: 24, padding: 28, width: 340, shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 16, elevation: 10 }}>
              {/* Close Button */}
              <TouchableOpacity onPress={() => setPinModalVisible(false)} style={{ position: 'absolute', top: 16, right: 16, zIndex: 2 }}>
                <Ionicons name="close" size={28} color="#ff3100" />
              </TouchableOpacity>
              
              <ThemedText style={{ color: '#FFFFFF', fontSize: 22, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' }}>
                Set App PIN
              </ThemedText>
              
              <ThemedText style={{ color: '#ffffff80', fontSize: 14, marginBottom: 20, textAlign: 'center' }}>
                Set a 4-digit PIN to secure your app. You'll need to enter this PIN when reopening the app.
              </ThemedText>
              
              {/* PIN Input */}
              <View style={{ marginBottom: 16 }}>
                <ThemedText style={{ color: '#ffffff80', fontSize: 14, marginBottom: 8 }}>
                  Enter 4-digit PIN
                </ThemedText>
                <View style={{
                  backgroundColor: '#181a2a',
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: '#ffffff20',
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingHorizontal: 16
                }}>
                  <Ionicons name="keypad" size={20} color="#ffffff80" style={{ marginRight: 12 }} />
                  <TextInput
                    style={{
                      flex: 1,
                      color: 'white',
                      fontSize: 16,
                      paddingVertical: 16
                    }}
                    placeholder="Enter 4-digit PIN"
                    placeholderTextColor="#ffffff80"
                    value={pin}
                    onChangeText={setPin}
                    keyboardType="numeric"
                    maxLength={4}
                    secureTextEntry={true}
                    autoCapitalize="none"
                    autoCorrect={false}
                  />
                </View>
              </View>

              {/* Confirm PIN Input */}
              <View style={{ marginBottom: 24 }}>
                <ThemedText style={{ color: '#ffffff80', fontSize: 14, marginBottom: 8 }}>
                  Confirm 4-digit PIN
                </ThemedText>
                <View style={{
                  backgroundColor: '#181a2a',
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: '#ffffff20',
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingHorizontal: 16
                }}>
                  <Ionicons name="keypad" size={20} color="#ffffff80" style={{ marginRight: 12 }} />
                  <TextInput
                    style={{
                      flex: 1,
                      color: 'white',
                      fontSize: 16,
                      paddingVertical: 16
                    }}
                    placeholder="Confirm 4-digit PIN"
                    placeholderTextColor="#ffffff80"
                    value={confirmPin}
                    onChangeText={setConfirmPin}
                    keyboardType="numeric"
                    maxLength={4}
                    secureTextEntry={true}
                    autoCapitalize="none"
                    autoCorrect={false}
                  />
                </View>
              </View>

              {/* Action Buttons */}
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 12 }}>
                <TouchableOpacity 
                  style={{ 
                    flex: 1, 
                    backgroundColor: '#ffffff20', 
                    borderRadius: 12, 
                    paddingVertical: 16,
                    alignItems: 'center'
                  }}
                  onPress={() => setPinModalVisible(false)}
                >
                  <ThemedText style={{ color: 'white', fontSize: 16, fontWeight: 'bold' }}>
                    Cancel
                  </ThemedText>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={{ 
                    flex: 1, 
                    backgroundColor: '#ff3100', 
                    borderRadius: 12, 
                    paddingVertical: 16,
                    alignItems: 'center',
                    opacity: isSettingPin ? 0.7 : 1
                  }}
                  onPress={handleSetPin}
                  disabled={isSettingPin}
                >
                  {isSettingPin ? (
                    <ActivityIndicator color="white" size="small" />
                  ) : (
                    <ThemedText style={{ color: 'white', fontSize: 16, fontWeight: 'bold' }}>
                      Set PIN
                    </ThemedText>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

        {/* Change Password Modal */}
        <Modal visible={changePasswordModalVisible} animationType="slide" transparent>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', alignItems: 'center' }}>
            <View style={{ backgroundColor: '#181830', borderRadius: 24, padding: 28, width: 340, shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 16, elevation: 10 }}>
              {/* Close Button */}
              <TouchableOpacity onPress={() => setChangePasswordModalVisible(false)} style={{ position: 'absolute', top: 16, right: 16, zIndex: 2 }}>
                <Ionicons name="close" size={28} color="#ff3100" />
              </TouchableOpacity>
              
              <ThemedText style={{ color: '#FFFFFF', fontSize: 22, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' }}>
                Change Password
              </ThemedText>
              
              {/* Current Password */}
              <View style={{ marginBottom: 16 }}>
                <ThemedText style={{ color: '#ffffff80', fontSize: 14, marginBottom: 8 }}>
                  Current Password
                </ThemedText>
                <View style={{
                  backgroundColor: '#181a2a',
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: '#ffffff20',
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingHorizontal: 16
                }}>
                  <Ionicons name="lock-closed" size={20} color="#ffffff80" style={{ marginRight: 12 }} />
                  <TextInput
                    style={{
                      flex: 1,
                      color: 'white',
                      fontSize: 16,
                      paddingVertical: 16
                    }}
                    placeholder="Enter current password"
                    placeholderTextColor="#ffffff80"
                    value={currentPassword}
                    onChangeText={setCurrentPassword}
                    secureTextEntry={!showCurrentPassword}
                    autoCapitalize="none"
                    autoCorrect={false}
                  />
                  <TouchableOpacity onPress={() => setShowCurrentPassword(!showCurrentPassword)}>
                    <Ionicons 
                      name={showCurrentPassword ? "eye-off" : "eye"} 
                      size={20} 
                      color="#ffffff80" 
                    />
                  </TouchableOpacity>
                </View>
              </View>

              {/* New Password */}
              <View style={{ marginBottom: 16 }}>
                <ThemedText style={{ color: '#ffffff80', fontSize: 14, marginBottom: 8 }}>
                  New Password
                </ThemedText>
                <View style={{
                  backgroundColor: '#181a2a',
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: '#ffffff20',
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingHorizontal: 16
                }}>
                  <Ionicons name="lock-closed" size={20} color="#ffffff80" style={{ marginRight: 12 }} />
                  <TextInput
                    style={{
                      flex: 1,
                      color: 'white',
                      fontSize: 16,
                      paddingVertical: 16
                    }}
                    placeholder="Enter new password"
                    placeholderTextColor="#ffffff80"
                    value={newPassword}
                    onChangeText={setNewPassword}
                    secureTextEntry={!showNewPassword}
                    autoCapitalize="none"
                    autoCorrect={false}
                  />
                  <TouchableOpacity onPress={() => setShowNewPassword(!showNewPassword)}>
                    <Ionicons 
                      name={showNewPassword ? "eye-off" : "eye"} 
                      size={20} 
                      color="#ffffff80" 
                    />
                  </TouchableOpacity>
                </View>
              </View>

              {/* Confirm Password */}
              <View style={{ marginBottom: 24 }}>
                <ThemedText style={{ color: '#ffffff80', fontSize: 14, marginBottom: 8 }}>
                  Confirm New Password
                </ThemedText>
                <View style={{
                  backgroundColor: '#181a2a',
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: '#ffffff20',
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingHorizontal: 16
                }}>
                  <Ionicons name="lock-closed" size={20} color="#ffffff80" style={{ marginRight: 12 }} />
                  <TextInput
                    style={{
                      flex: 1,
                      color: 'white',
                      fontSize: 16,
                      paddingVertical: 16
                    }}
                    placeholder="Confirm new password"
                    placeholderTextColor="#ffffff80"
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                    secureTextEntry={!showConfirmPassword}
                    autoCapitalize="none"
                    autoCorrect={false}
                  />
                  <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)}>
                    <Ionicons 
                      name={showConfirmPassword ? "eye-off" : "eye"} 
                      size={20} 
                      color="#ffffff80" 
                    />
                  </TouchableOpacity>
                </View>
              </View>

              {/* Action Buttons */}
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 12 }}>
                <TouchableOpacity 
                  style={{ 
                    flex: 1, 
                    backgroundColor: '#ffffff20', 
                    borderRadius: 12, 
                    paddingVertical: 16,
                    alignItems: 'center'
                  }}
                  onPress={() => setChangePasswordModalVisible(false)}
                >
                  <ThemedText style={{ color: 'white', fontSize: 16, fontWeight: 'bold' }}>
                    Cancel
                  </ThemedText>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={{ 
                    flex: 1, 
                    backgroundColor: '#ff3100', 
                    borderRadius: 12, 
                    paddingVertical: 16,
                    alignItems: 'center',
                    opacity: isChangingPassword ? 0.7 : 1
                  }}
                  onPress={handleChangePassword}
                  disabled={isChangingPassword}
                >
                  {isChangingPassword ? (
                    <ActivityIndicator color="white" size="small" />
                  ) : (
                    <ThemedText style={{ color: 'white', fontSize: 16, fontWeight: 'bold' }}>
                      Change Password
                    </ThemedText>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </ThemedView>
    </SafeAreaView>
  );
} 