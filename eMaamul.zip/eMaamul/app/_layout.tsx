import { AuthProvider } from '@/components/AuthContext';
import { AuthGuard } from '@/components/AuthGuard';
import { InventoryProvider } from '@/components/InventoryContext';
import { useColorScheme as useNativeColorScheme } from 'react-native';
import { Stack } from 'expo-router';
import React from 'react';
import 'react-native-gesture-handler';

type ColorScheme = 'light' | 'dark' | null | undefined;

export default function RootLayout() {
  const colorScheme: ColorScheme = useNativeColorScheme();

  return (
    <AuthProvider>
      <AuthGuard>
        <InventoryProvider>
          <Stack>
            <Stack.Screen name="login" options={{ headerShown: false }} />
            <Stack.Screen name="pin-verification" options={{ headerShown: false }} />
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          </Stack>
        </InventoryProvider>
      </AuthGuard>
    </AuthProvider>
  );
}
