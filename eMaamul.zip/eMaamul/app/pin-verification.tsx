import { useAuth } from '@/components/AuthContext';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { router } from 'expo-router';
import React, { useRef, useState } from 'react';
import {
    Alert,
    KeyboardAvoidingView,
    Platform,
    ScrollView,
    StyleSheet,
    TextInput,
    TouchableOpacity
} from 'react-native';

export default function PinVerificationScreen() {
  const [pin, setPin] = useState(['', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const { user, logout, verifyPIN } = useAuth();
  const inputRefs = useRef<TextInput[]>([]);

  const handlePinChange = (text: string, index: number) => {
    const newPin = [...pin];
    newPin[index] = text;
    setPin(newPin);

    // Auto-focus to next input
    if (text && index < 3) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyPress = (e: any, index: number) => {
    if (e.nativeEvent.key === 'Backspace' && !pin[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerifyPin = async () => {
    const pinString = pin.join('');
    
    if (pinString.length !== 4) {
      Alert.alert('Khalad', 'Fadlan geli PIN-ka oo dhammeystiran (4 xaraf)');
      return;
    }

    setIsLoading(true);
    try {
      const isValid = await verifyPIN(pinString);
      
      if (isValid) {
        // If PIN is correct, navigate to main app
        router.replace('/(tabs)');
      } else {
        Alert.alert('Khalad', 'PIN-ka waa khaldan');
        setPin(['', '', '', '']);
        inputRefs.current[0]?.focus();
      }
    } catch (error) {
      Alert.alert('Khalad', 'Waxaa dhacay khalad aad u weyn');
      setPin(['', '', '', '']);
      inputRefs.current[0]?.focus();
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    Alert.alert(
      'Ka bixitaanka',
      'Ma hubtaa inaad ka bixeyso?',
      [
        { text: 'Maya', style: 'cancel' },
        {
          text: 'Haa',
          onPress: async () => {
            try {
              await logout();
              // Navigation will be handled by AuthGuard
            } catch (error) {
              console.error('Logout error:', error);
            }
          },
        },
      ]
    );
  };

  return (
    <ThemedView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardAvoidingView}
      >
        <ScrollView contentContainerStyle={styles.scrollView}>
          <ThemedView style={styles.formContainer}>
            <ThemedText style={styles.title}>PIN-ka Hubi</ThemedText>
            <ThemedText style={styles.subtitle}>
              Fadlan geli PIN-kaaga si aad u galiso
            </ThemedText>

            <ThemedView style={styles.pinContainer}>
              {pin.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={(ref) => {
                    if (ref) inputRefs.current[index] = ref;
                  }}
                  style={styles.pinInput}
                  value={digit}
                  onChangeText={(text) => handlePinChange(text, index)}
                  onKeyPress={(e) => handleKeyPress(e, index)}
                  keyboardType="numeric"
                  maxLength={1}
                  secureTextEntry
                  textAlign="center"
                  placeholder="•"
                  placeholderTextColor="#666"
                />
              ))}
            </ThemedView>

            <TouchableOpacity
              style={[styles.verifyButton, isLoading && styles.verifyButtonDisabled]}
              onPress={handleVerifyPin}
              disabled={isLoading}
            >
              <ThemedText style={styles.verifyButtonText}>
                {isLoading ? 'Hubinaya...' : 'Hubi'}
              </ThemedText>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.logoutButton}
              onPress={handleLogout}
            >
              <ThemedText style={styles.logoutButtonText}>
                Ka bixi
              </ThemedText>
            </TouchableOpacity>
          </ThemedView>
        </ScrollView>
      </KeyboardAvoidingView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#00002b',
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  scrollView: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  formContainer: {
    backgroundColor: '#001122',
    borderRadius: 12,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    color: '#ffffff',
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 32,
    color: '#cccccc',
  },
  pinContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 32,
    paddingHorizontal: 20,
  },
  pinInput: {
    backgroundColor: '#002244',
    borderRadius: 8,
    width: 60,
    height: 60,
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
    borderWidth: 1,
    borderColor: '#003366',
    textAlign: 'center',
  },
  verifyButton: {
    backgroundColor: '#ff3100',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  verifyButtonDisabled: {
    backgroundColor: '#666666',
  },
  verifyButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  logoutButton: {
    backgroundColor: 'transparent',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#666666',
  },
  logoutButtonText: {
    color: '#666666',
    fontSize: 16,
  },
}); 