import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut
} from 'firebase/auth';
import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth } from '../config/firebase';

interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; message: string }>;
  register: (email: string, password: string) => Promise<{ success: boolean; message: string }>;
  logout: () => Promise<{ success: boolean; message: string }>;
  signOut: () => Promise<void>;
  checkAuthState: () => Promise<void>;
  checkPINExists: () => Promise<boolean>;
  verifyPIN: (pin: string) => Promise<boolean>;
  setPIN: (pin: string) => Promise<{ success: boolean; message: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Listen to Firebase Auth state changes
  useEffect(() => {
    if (!auth) {
      console.log('AuthContext: Firebase auth not available, using mock user');
      setUser({
        uid: 'mock-user-id',
        email: 'test@example.com',
        displayName: 'Test User'
      });
      setIsLoading(false);
      return;
    }

    try {
      const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
        if (firebaseUser) {
          setUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email,
            displayName: firebaseUser.displayName
          });
        } else {
          setUser(null);
        }
        setIsLoading(false);
      }, (error) => {
        console.error('Auth state change error:', error);
        setIsLoading(false);
      });

      return () => unsubscribe();
    } catch (error) {
      console.error('Auth state listener error:', error);
      setUser({
        uid: 'mock-user-id',
        email: 'test@example.com',
        displayName: 'Test User'
      });
      setIsLoading(false);
    }
  }, []);

  const login = async (email: string, password: string) => {
    if (!auth) {
      console.log('AuthContext: Mock login - Firebase auth not available');
      // Mock login for testing
      setUser({
        uid: 'mock-user-id',
        email: email,
        displayName: 'Test User'
      });
      return { success: true, message: 'Mock login successful' };
    }
    
    try {
      setIsLoading(true);
      await signInWithEmailAndPassword(auth, email, password);
      return { success: true, message: 'Login successful' };
    } catch (error: any) {
      console.error('Login error:', error);
      return { success: false, message: error.message || 'Login failed' };
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (email: string, password: string) => {
    if (!auth) {
      console.log('AuthContext: Mock register - Firebase auth not available');
      // Mock registration for testing
      setUser({
        uid: 'mock-user-id',
        email: email,
        displayName: 'Test User'
      });
      return { success: true, message: 'Mock registration successful' };
    }
    
    try {
      setIsLoading(true);
      await createUserWithEmailAndPassword(auth, email, password);
      return { success: true, message: 'Registration successful' };
    } catch (error: any) {
      console.error('Registration error:', error);
      return { success: false, message: error.message || 'Registration failed' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    if (!auth) {
      console.log('AuthContext: Mock logout - Firebase auth not available');
      setUser(null);
      return { success: true, message: 'Mock logout successful' };
    }
    
    try {
      await firebaseSignOut(auth);
      setUser(null);
      return { success: true, message: 'Logout successful' };
    } catch (error) {
      console.error('Error signing out:', error);
      return { success: false, message: 'Failed to sign out' };
    }
  };

  const signOut = async () => {
    if (!auth) {
      console.log('AuthContext: Mock sign out - Firebase auth not available');
      setUser(null);
      return;
    }
    
    try {
      await firebaseSignOut(auth);
      setUser(null);
    } catch (error) {
      console.error('Error signing out:', error);
      throw error;
    }
  };

  const checkAuthState = async () => {
    // This is handled by onAuthStateChanged listener
    console.log('AuthContext: Auth state check - user:', user ? 'logged in' : 'not logged in');
  };

  const checkPINExists = async () => {
    try {
      const pin = await AsyncStorage.getItem('user_pin');
      return pin !== null;
    } catch (error) {
      console.error('Error checking PIN:', error);
      return false;
    }
  };

  const verifyPIN = async (pin: string) => {
    try {
      const storedPin = await AsyncStorage.getItem('user_pin');
      return storedPin === pin;
    } catch (error) {
      console.error('Error verifying PIN:', error);
      return false;
    }
  };

  const setPIN = async (pin: string) => {
    try {
      await AsyncStorage.setItem('user_pin', pin);
      return { success: true, message: 'PIN set successfully' };
    } catch (error) {
      console.error('Error setting PIN:', error);
      return { success: false, message: 'Failed to set PIN' };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        login,
        register,
        logout,
        signOut,
        checkAuthState,
        checkPINExists,
        verifyPIN,
        setPIN,
      }}>
      {children}
    </AuthContext.Provider>
  );
};