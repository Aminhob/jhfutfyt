import { useAuth } from '@/components/AuthContext';
import { router } from 'expo-router';
import React, { useEffect } from 'react';
import { ActivityIndicator } from 'react-native';
import { ThemedText } from './ThemedText';
import { ThemedView } from './ThemedView';

export const AuthGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading, checkPINExists } = useAuth();

  useEffect(() => {
    const handleAuthState = async () => {
      if (!isLoading) {
        if (user) {
          // User is logged in, check if PIN is required
          const hasPIN = await checkPINExists();
          if (hasPIN) {
            router.replace('/pin-verification');
          } else {
            router.replace('/(tabs)');
          }
        } else {
          router.replace('/login');
        }
      }
    };

    handleAuthState();
  }, [user, isLoading, checkPINExists]);

  if (isLoading) {
    return (
      <ThemedView style={{ flex: 1, backgroundColor: '#00002b', justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#ff3100" />
        <ThemedText style={{ color: 'white', marginTop: 16, fontSize: 16 }}>
          Loading...
        </ThemedText>
      </ThemedView>
    );
  }

  return <>{children}</>;
};