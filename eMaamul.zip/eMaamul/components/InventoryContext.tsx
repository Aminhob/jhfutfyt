import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface Product {
  id: string;
  name: string;
  price: number;
  quantity: number;
  barcode?: string;
  category?: string;
  lastUpdated?: Date;
}

interface InventoryContextType {
  products: Product[];
  loading: boolean;
  error: string | null;
  addProduct: (product: Omit<Product, 'id' | 'lastUpdated'>) => Promise<void>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  getProduct: (id: string) => Product | undefined;
  searchProducts: (query: string) => Product[];
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

export const InventoryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Load products from storage/API on mount
  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true);
        // TODO: Replace with actual API call or AsyncStorage
        // const storedProducts = await AsyncStorage.getItem('products');
        // setProducts(storedProducts ? JSON.parse(storedProducts) : []);
        setProducts([]); // Temporary empty array
      } catch (err) {
        setError('Failed to load products');
        console.error('Error loading products:', err);
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, []);

  const saveProducts = async (updatedProducts: Product[]) => {
    try {
      // TODO: Replace with actual API call or AsyncStorage
      // await AsyncStorage.setItem('products', JSON.stringify(updatedProducts));
      setProducts(updatedProducts);
    } catch (err) {
      setError('Failed to save products');
      console.error('Error saving products:', err);
      throw err;
    }
  };

  const addProduct = async (product: Omit<Product, 'id' | 'lastUpdated'>) => {
    try {
      const newProduct: Product = {
        ...product,
        id: Date.now().toString(),
        lastUpdated: new Date(),
      };
      const updatedProducts = [...products, newProduct];
      await saveProducts(updatedProducts);
    } catch (err) {
      setError('Failed to add product');
      console.error('Error adding product:', err);
      throw err;
    }
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    try {
      const updatedProducts = products.map(product =>
        product.id === id 
          ? { ...product, ...updates, lastUpdated: new Date() } 
          : product
      );
      await saveProducts(updatedProducts);
    } catch (err) {
      setError('Failed to update product');
      console.error('Error updating product:', err);
      throw err;
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      const updatedProducts = products.filter(product => product.id !== id);
      await saveProducts(updatedProducts);
    } catch (err) {
      setError('Failed to delete product');
      console.error('Error deleting product:', err);
      throw err;
    }
  };

  const getProduct = (id: string) => {
    return products.find(product => product.id === id);
  };

  const searchProducts = (query: string) => {
    if (!query.trim()) return products;
    const searchTerm = query.toLowerCase();
    return products.filter(
      product =>
        product.name.toLowerCase().includes(searchTerm) ||
        (product.barcode && product.barcode.includes(searchTerm)) ||
        (product.category && product.category.toLowerCase().includes(searchTerm))
    );
  };

  return (
    <InventoryContext.Provider
      value={{
        products,
        loading,
        error,
        addProduct,
        updateProduct,
        deleteProduct,
        getProduct,
        searchProducts,
      }}>
      {children}
    </InventoryContext.Provider>
  );
};

export const useInventory = (): InventoryContextType => {
  const context = useContext(InventoryContext);
  if (context === undefined) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
};

export default InventoryContext;
