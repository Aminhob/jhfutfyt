import { addDoc, collection, deleteDoc, doc, onSnapshot, query, setDoc, where } from 'firebase/firestore';
import React, { createContext, useContext, useEffect, useState } from 'react';
import { db } from '../config/firebase';
import { useAuth } from './AuthContext';

export type Transaction = {
  id: string;
  type: 'income' | 'expense';
  label: string;
  amount: number;
  date: string;
  icon: string;
  productId?: string;
};

interface TransactionsContextType {
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id'>) => Promise<Transaction | null>;
  updateTransaction: (id: string, update: Partial<Transaction>) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;
  clearTransactions: () => void;
  isLoading: boolean;
}

const TransactionsContext = createContext<TransactionsContextType | undefined>(undefined);

export function useTransactions() {
  const ctx = useContext(TransactionsContext);
  if (!ctx) throw new Error('useTransactions must be used within TransactionsProvider');
  return ctx;
}

export const TransactionsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Load transactions for the current user
  useEffect(() => {
    // Clear transactions when user changes or becomes null
    if (!user) {
      console.log('TransactionsContext: No user, clearing transactions');
      setTransactions([]);
      setIsLoading(false);
      return;
    }
    
    if (!db) {
      console.log('TransactionsContext: Firestore not available, using mock data');
      // Load mock data when Firebase is not available
      const mockTransactions: Transaction[] = [
        {
          id: '1',
          type: 'income',
          label: 'Sample Sale',
          amount: 150,
          date: new Date().toISOString().slice(0, 10),
          icon: 'trending-up',
          productId: '1'
        },
        {
          id: '2',
          type: 'expense',
          label: 'Sample Expense',
          amount: 50,
          date: new Date().toISOString().slice(0, 10),
          icon: 'trending-down'
        }
      ];
      setTransactions(mockTransactions);
      setIsLoading(false);
      return;
    }
    
    console.log('TransactionsContext: Loading transactions for user:', user.uid);
    setIsLoading(true);
    setTransactions([]); // Clear existing transactions before loading new ones
    
    const q = query(collection(db, 'transactions'), where('userId', '==', user.uid));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const transactionsData: Transaction[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        transactionsData.push({
          id: doc.id,
          type: data.type || 'income',
          label: data.label || '',
          amount: data.amount || 0,
          date: data.date || new Date().toISOString().slice(0, 10),
          icon: data.icon || 'trending-up',
          productId: data.productId || undefined,
        });
      });
      
      console.log('TransactionsContext: Transactions loaded:', transactionsData.length);
      setTransactions(transactionsData);
      setIsLoading(false);
    }, (error) => {
      console.error('TransactionsContext: Error loading transactions:', error);
      setIsLoading(false);
    });
    
    return () => {
      console.log('TransactionsContext: Cleaning up listener for user:', user.uid);
      unsubscribe();
    };
  }, [user?.uid]);

  // Add a transaction for the current user
  const addTransaction = async (transaction: Omit<Transaction, 'id'>) => {
    if (!user) return null;
    
    if (!db) {
      // Mock implementation when Firebase is not available
      const newTransaction: Transaction = {
        ...transaction,
        id: Date.now().toString(),
      };
      setTransactions(prev => [...prev, newTransaction]);
      return newTransaction;
    }
    
    try {
      const docRef = await addDoc(collection(db, 'transactions'), { 
        ...transaction, 
        userId: user.uid 
      });
      return { ...transaction, id: docRef.id };
    } catch (error) {
      console.error('Error adding transaction:', error);
      return null;
    }
  };

  // Update a transaction
  const updateTransaction = async (id: string, update: Partial<Transaction>) => {
    if (!user) return;
    
    if (!db) {
      // Mock implementation when Firebase is not available
      setTransactions(prev => 
        prev.map(transaction => 
          transaction.id === id ? { ...transaction, ...update } : transaction
        )
      );
      return;
    }
    
    try {
      const transactionRef = doc(db, 'transactions', id);
      await setDoc(transactionRef, update, { merge: true });
    } catch (error) {
      console.error('Error updating transaction:', error);
    }
  };

  // Delete a transaction
  const deleteTransaction = async (id: string) => {
    if (!user) return;
    
    if (!db) {
      // Mock implementation when Firebase is not available
      setTransactions(prev => prev.filter(transaction => transaction.id !== id));
      return;
    }
    
    try {
      const transactionRef = doc(db, 'transactions', id);
      await deleteDoc(transactionRef);
    } catch (error) {
      console.error('Error deleting transaction:', error);
    }
  };

  // Clear transactions (local state only)
  const clearTransactions = () => {
    setTransactions([]);
    console.log('TransactionsContext: Transactions cleared');
  };

  return (
    <TransactionsContext.Provider value={{ 
      transactions, 
      addTransaction, 
      updateTransaction, 
      deleteTransaction, 
      clearTransactions, 
      isLoading 
    }}>
      {children}
    </TransactionsContext.Provider>
  );
};