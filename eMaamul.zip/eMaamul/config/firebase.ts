import { FirebaseApp, getApps, initializeApp } from 'firebase/app';
import { Auth, getAuth } from 'firebase/auth';
import { Firestore, getFirestore } from 'firebase/firestore';

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCW4yM4slTwRd1z6cXabCoTttoNXKq_NkY",
  authDomain: "emaamuldata.firebaseapp.com",
  projectId: "emaamuldata",
  storageBucket: "emaamuldata.firebasestorage.app",
  messagingSenderId: "178824845965",
  appId: "1:178824845965:web:1f7cae9713ce6077ffa0c4",
  measurementId: "G-JXN27LB1GN"
};

// Initialize Firebase
let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

try {
  // Initialize Firebase App
  if (getApps().length === 0) {
    app = initializeApp(firebaseConfig);
    console.log('✅ Firebase app initialized successfully');
  } else {
    app = getApps()[0];
    console.log('✅ Using existing Firebase app');
  }
  
  // Initialize Auth - simplified approach for React Native
  auth = getAuth(app);
  console.log('✅ Firebase Auth initialized successfully');
  
  // Initialize Firestore
  db = getFirestore(app);
  console.log('✅ Firestore initialized successfully');
  
} catch (error) {
  console.error('❌ Firebase initialization error:', error);
  app = null;
  auth = null;
  db = null;
}

export { auth, db };

export default app;