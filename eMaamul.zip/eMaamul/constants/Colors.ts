/**
 * Below are the colors that are used in the app. The colors are defined in the light and dark mode.
 * There are many other ways to style your app. For example, [Nativewind](https://www.nativewind.dev/), [Tamagui](https://tamagui.dev/), [unistyles](https://reactnativeunistyles.vercel.app), etc.
 */

const tintColorLight = '#ff3100';
const tintColorDark = '#ff3100';

export const Colors = {
  light: {
    text: '#ffffff',
    background: '#00002b',
    tint: tintColorLight,
    icon: '#ffffff',
    tabIconDefault: '#ffffff',
    tabIconSelected: tintColorLight,
    income: '#4CAF50', // Keep green for income
  },
  dark: {
    text: '#ffffff',
    background: '#00002b',
    tint: tintColorDark,
    icon: '#ffffff',
    tabIconDefault: '#ffffff',
    tabIconSelected: tintColorDark,
    income: '#4CAF50', // Keep green for income
  },
};
