const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Add resolver configuration to help with TurboModule resolution
config.resolver.platforms = ['native', 'android', 'ios', 'web'];

module.exports = config;
