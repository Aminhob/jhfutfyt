// import { auth } from '@/config/firebase';
import AsyncStorage from '@react-native-async-storage/async-storage';
// import { signOut as fbSignOut, GoogleAuthProvider, onAuthStateChanged, signInWithCredential } from 'firebase/auth';
import { create, StateCreator } from 'zustand';

export type AuthUser = {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
};

export interface AuthState {
  user: AuthUser | null;
  isInitializing: boolean;
  error?: string;
  init: () => void;
  completeGoogleSignIn: (params: { idToken?: string; accessToken?: string }) => Promise<void>;
  signOut: () => Promise<void>;
}

const authStoreCreator: StateCreator<AuthState> = (set, get) => ({
  user: null,
  isInitializing: true,
  error: undefined,
  init: () => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const u: AuthUser = {
          uid: fbUser.uid,
          email: fbUser.email,
          displayName: fbUser.displayName,
          photoURL: fbUser.photoURL,
        };
        set({ user: u, isInitializing: false, error: undefined });
        await AsyncStorage.setItem('userSession', JSON.stringify(u));
      } else {
        set({ user: null, isInitializing: false });
        await AsyncStorage.removeItem('userSession');
      }
    });
    // It's okay not to expose unsubscribe; store is app-wide.
  },
  completeGoogleSignIn: async ({ idToken, accessToken }) => {
    try {
      // Firebase requires either an ID token or access token to create a Google credential
      const credential = GoogleAuthProvider.credential(idToken, accessToken);
      await signInWithCredential(auth, credential);
    } catch (e: any) {
      set({ error: e?.message ?? 'Failed to sign in with Google' });
      throw e;
    }
  },
  signOut: async () => {
    await fbSignOut(auth);
    set({ user: null });
  },
});

export const useAuthStore = create<AuthState>(authStoreCreator);
