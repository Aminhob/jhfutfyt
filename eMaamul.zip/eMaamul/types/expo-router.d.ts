declare module 'expo-router' {
  import * as React from 'react';
  
  export interface RouterProps {
    children?: React.ReactNode;
  }
  
  export interface StackScreenProps {
    name: string;
    options?: any;
    children?: React.ReactNode;
  }
  
  export interface StackProps {
    children?: React.ReactNode;
    screenOptions?: any;
  }
  
  export function Stack(props: StackProps): React.JSX.Element;
  export namespace Stack {
    export function Screen(props: StackScreenProps): React.JSX.Element;
  }
  export const Tabs: React.ComponentType<any>;
  export const Drawer: React.ComponentType<any>;
  export const Slot: React.ComponentType<RouterProps>;
  
  export function useRouter(): {
    push: (href: string) => void;
    replace: (href: string) => void;
    back: () => void;
    canGoBack: () => boolean;
  };
  
  export function useLocalSearchParams(): Record<string, string | string[]>;
  export function useGlobalSearchParams(): Record<string, string | string[]>;
  export function useSegments(): string[];
  export function usePathname(): string;
  
  export const router: {
    push: (href: string) => void;
    replace: (href: string) => void;
    back: () => void;
    canGoBack: () => boolean;
  };
  
  export const Link: ComponentType<{
    href: string;
    children?: React.ReactNode;
    [key: string]: any;
  }>;
  
  export const Redirect: ComponentType<{
    href: string;
  }>;
}
