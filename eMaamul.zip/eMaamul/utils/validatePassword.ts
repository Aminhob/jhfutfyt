// utils/validatePassword.ts

/**
 * Checks if the password meets minimum requirements.
 * @param password The password string to validate.
 * @returns true if valid, false otherwise
 */
export function validatePassword(password: string): boolean {
  return password.length >= 6;
} 